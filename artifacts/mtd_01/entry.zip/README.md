# Fixed stack plus changepoint MTD candidate

Install pinned requirements.txt in the organizer's Python image. Offline command:

python predict.py --data /data --out /output/submission.csv --model model --mtd mtd.json

Payout order: 0,1,2,5,20. This is a candidate, not a submitted entry.

# All-In frozen-blend main entry

Season: 5fffdc4d0c700bbf61c3f911. Round: main. Select the registered team in the form.
Deployment mode: `mean`. All four recorded fold recipes and six CatBoost checkpoints
are unchanged. See policy_change.json and docs/blend-promotion.md for authorization,
the post-evaluation policy change, and the distinction between OOF evidence and test
aggregation. No new fit, weight optimization, calibration, or configuration search.

## Reproduce offline

Python 3.13.7 tested. Organizers install exact root-level
requirements.txt dependencies before the offline run. No JAX, REA, Databricks,
MLflow, credentials or APIs are required for prediction.

```sh
python predict.py --data /data --out /output/submission.csv --model model
```

Read-only inputs: /data/test/queries.csv and history.csv. Saved models/prior/recipes
and feature schema are under model/. The uploaded CSV is not an input. Outputs
follow 0,1,2,5,20 payout order. Only /output and /tmp need be writable.

Forecast SHA-256: a3f79eb791f1a49adf0a0fb4f8f24ac334f1c5b4586720604f7b596ee5e1aec8
The score 31.7023316677 describes the preserved held-fold validation predictions;
it is not a measured hidden-test score or an independently validated score of
averaging all four recipes. Validation was already used during development.

The original HMM submission remains separately preserved by the project.
Source identity is in source_manifest.json; weights/checkpoint hashes are in
frozen_artifacts.json. Required license notices are included. This code loads saved
parameters and never trains; seeds remain 20261108 and 20261109 for the CatBoost fits.

Fresh offline clean-extraction replay was byte-identical in 5.751 seconds, peak child RSS 263.6 MiB. See reproduction.json.

# All-In round-one probability forecaster

Predicts payout probabilities in order **0, 1, 2, 5, 20** using the released
main participant kit. The controlled Dynamax partial-pooling experiment is
complete. Its small holdout advantage did not pass the frozen retention gate,
so final forecasts use the shared Dynamax HMM checkpoint.

The upload files are `artifacts/final/submission.csv` and `artifacts/final/entry.zip`.
They are prepared locally; uploading through the organizers' form is separate.
See `docs/results.md` for official scores, uncertainty and limitations,
`docs/source-map.md` for source tracing, and `docs/evidence-ledger.md` for evidence.

## Reproduce the CSV offline

Python 3.13.7 was tested. Final inference needs only the standard library:

```sh
python3 predict.py --data /absolute/path/to/main-participants-60-40/public --out /tmp/submission.csv
python3 organizer/check_submission.py /tmp/submission.csv --data /absolute/path/to/main-participants-60-40/public
```

The saved population model is `artifacts/experiment/population.json`, and the
deployment choice is in `artifacts/experiment/holdout.json`. The portable forward
recurrence is checked against upstream JAX predictions on all validation and
test queries. Inference does not require REA, Databricks, MLflow or network access.

## Reproduce the investigation

From this project root, install the exact training environment and set the kit path:

```sh
python3.13 -m venv .venv
.venv/bin/python -m pip install -r requirements-training.lock
DATA=/absolute/path/to/main-participants-60-40/public
.venv/bin/python organizer/run_starter.py --data "$DATA" --out artifacts/baseline-replay
.venv/bin/python scripts/verify.py --data "$DATA" --out artifacts/verification-replay
.venv/bin/python scripts/window_probe.py
.venv/bin/python scripts/experiment.py develop --data "$DATA" --out artifacts/experiment-replay
.venv/bin/python scripts/experiment.py audit --data "$DATA" --out artifacts/experiment-replay
.venv/bin/python predict.py --data "$DATA" --out /tmp/dynamax.csv --engine dynamax
.venv/bin/python scripts/package_entry.py --data "$DATA"
```

Use fresh output directories; existing finalist and holdout files are deliberately
protected from silent overwrite. `scripts/verify.py` uses the preserved original
experiment checkpoint to test the exact delivered population. Its clean-source
replay trains the unmodified class. The experiment uses the committed split list,
not a newly randomized partition. Repeating the audit is a numerical reproduction,
not another independent holdout experiment.

`artifacts/splits.json` fixes 48 development and 48 holdout episodes (12 per
condition in each). One population fit on training histories supports the shared
control, unshrunk adaptation, and three shrinkage settings. No validation outcome
or target is used in fitting; development targets select precision. Holdout is
used once for the predeclared confirmatory gate. No later tuning occurred.

The inherited project contained the split, patch and development results when
this work began; they were audited and preserved rather than overwritten.
The supplied workspace has no Databricks integration or CatBoost benchmark.
The existing experiment's local MLflow fallback was retained. Package versions,
data hashes, source revision, patch hash, parameters, predictions, diagnostics and
run ID are under `artifacts/`. No secrets are packaged.

Upstream Dynamax is pinned to `ffc626bf89bf07c7ae7064922f6a373d013c4b17`.
The readable patch is `artifacts/dynamax.patch`; the original categorical module
is `research/upstream_categorical_glm_hmm.py`. MIT attribution and citation are in
`THIRD_PARTY_NOTICES.md` and the vendored license files.

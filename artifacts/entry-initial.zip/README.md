# All-In main-round entry

Round: main. Season: 5fffdc4d0c700bbf61c3f911. Select the registered team in the organizer form.
Model: shared categorical-regression HMM trained with Dynamax; partial pooling
was tested and rejected by the frozen confirmatory gate. See docs/results.md.

## Reproduction

Python 3.13.7 tested, standard library only. No package installation is needed for
the default command. Run from the extracted ZIP root:

```sh
python predict.py --data /data --out /output/submission.csv
```

Inputs: released queries.csv and history.csv under /data/test/. Required checkpoint:
artifacts/experiment/population.json. Selection: artifacts/experiment/holdout.json.
The runner reads saved parameters; it does not retrain. No network, APIs, REA,
Databricks or credentials are required. Source can be mounted read-only. The
uploaded forecast CSV is not an input. Scratch files are not needed.

Forecast SHA-256: `655c228fc0c767e66b58c9f57f7c35452aef0e2f9b520c8bbb89d1e30792f236`.
Output order: query_id,p_0,p_1,p_2,p_5,p_20. Seed: 20261107.
Settings and data/split/source hashes: artifacts/experiment/config.json and
artifacts/*.json. Code identity: source_manifest.json. Licenses and attribution:
THIRD_PARTY_NOTICES.md and research/vendor/dynamax/LICENSE.

The official checker accepted all 1536 test rows. A fresh
extracted package rerun with site packages and sockets disabled produced a
byte-identical CSV in 2.182 seconds on macOS-15.5-arm64-arm-64bit-Mach-O,
peak child RSS 180.6 MiB, using one thread.
The measured maximum discrepancy against JAX on test was 2.22e-16,
below the 1e-8 limit. Organizer Linux has not been executed locally.

## Training and investigation

Final inference needs no dependencies. To reproduce training, separately install
the exact versions in requirements-training.lock into a Python 3.13 environment,
then use the commands in docs/project-readme.md with the released data path.
Use new output folders. Training and adaptation source, clean upstream control,
readable patch, saved checkpoints and numerical checks are included. Repeating
the holdout audit reproduces a result; it does not create fresh holdout evidence.
No adaptation-round data or practice-demo internals were used.
